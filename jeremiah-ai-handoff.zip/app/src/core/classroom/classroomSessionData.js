export const currentSession = {
  studyId: "OG",
  studyTitle: "The One True God",
  standardId: "OG.1.18",
  standardTitle: "God is One",
  sessionType: "Resume Session",
  currentStageId: "checkpoint",
  currentStage: "Scripture Review",
  learnerLevel: "Adult Endpoint Path",
  truthStatement: "There is one God.",
  truthExplanation:
    "This session teaches the biblical truth that God is one, not many. Jeremiah AI guides the learner through the scriptures that prove this, corrects weak understanding, and moves toward mastery.",
  verses: [
    {
      reference: "Deuteronomy 6:4",
      text: "Hear, O Israel: The LORD our God is one LORD.",
      note: "This verse states the oneness of God directly and serves as a foundational testimony.",
    },
    {
      reference: "Isaiah 44:6",
      text: "I am the first, and I am the last; and beside me there is no God.",
      note: "This verse rules out the existence of another divine being alongside God.",
    },
  ],
  checkpoint: {
    title: "What do these verses require you to confess?",
    description:
      "Jeremiah AI is checking whether the learner understands what these passages prove, not just whether they can repeat the words.",
    prompt:
      "These verses do not merely mention God. They make a doctrinal claim. What do they rule out, and what do they require you to confess instead?",
  },
};